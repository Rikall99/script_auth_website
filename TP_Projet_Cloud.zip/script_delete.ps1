# Set the VPC ID
$VPC_ID = "vpc-0d77c75687be5f977"

# Delete EC2 instances
Write-Output "Deleting EC2 instances..."
$INSTANCE_IDS = (aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC_ID" --query "Reservations[*].Instances[*].InstanceId" --output text) -split "\s+"
if ($INSTANCE_IDS) {
    aws ec2 terminate-instances --instance-ids $INSTANCE_IDS
    aws ec2 wait instance-terminated --instance-ids $INSTANCE_IDS
}

# Delete NAT Gateways
Write-Output "Deleting NAT Gateways..."
$NAT_GATEWAY_IDS = (aws ec2 describe-nat-gateways --filter "Name=vpc-id,Values=$VPC_ID" --query "NatGateways[*].NatGatewayId" --output text) -split "\s+"
foreach ($nat_gateway_id in $NAT_GATEWAY_IDS) {
    aws ec2 delete-nat-gateway --nat-gateway-id $nat_gateway_id
    aws ec2 wait nat-gateway-deleted --nat-gateway-ids $nat_gateway_id
}

# Detach and delete Internet Gateways
Write-Output "Detaching and deleting Internet Gateways..."
$INTERNET_GATEWAY_IDS = (aws ec2 describe-internet-gateways --filters "Name=attachment.vpc-id,Values=$VPC_ID" --query "InternetGateways[*].InternetGatewayId" --output text) -split "\s+"
foreach ($igw_id in $INTERNET_GATEWAY_IDS) {
    aws ec2 detach-internet-gateway --internet-gateway-id $igw_id --vpc-id $VPC_ID
    aws ec2 delete-internet-gateway --internet-gateway-id $igw_id
}

# Delete Security Groups (except the default one)
Write-Output "Deleting Security Groups..."
$SECURITY_GROUP_IDS = (aws ec2 describe-security-groups --filters "Name=vpc-id,Values=$VPC_ID" --query "SecurityGroups[?GroupName!='default'].GroupId" --output text) -split "\s+"
foreach ($sg_id in $SECURITY_GROUP_IDS) {
    aws ec2 delete-security-group --group-id $sg_id
}

# Delete Subnets
Write-Output "Deleting Subnets..."
$SUBNET_IDS = (aws ec2 describe-subnets --filters "Name=vpc-id,Values=$VPC_ID" --query "Subnets[*].SubnetId" --output text) -split "\s+"
foreach ($subnet_id in $SUBNET_IDS) {
    aws ec2 delete-subnet --subnet-id $subnet_id
}

# Delete Route Tables (except the main one)
Write-Output "Deleting Route Tables..."
$ROUTE_TABLE_IDS = (aws ec2 describe-route-tables --filters "Name=vpc-id,Values=$VPC_ID" --query "RouteTables[?Associations[0].Main!=true].RouteTableId" --output text) -split "\s+"
foreach ($rt_id in $ROUTE_TABLE_IDS) {
    aws ec2 delete-route-table --route-table-id $rt_id
}

# Delete Network ACLs (except the default one)
Write-Output "Deleting Network ACLs..."
$NETWORK_ACL_IDS = (aws ec2 describe-network-acls --filters "Name=vpc-id,Values=$VPC_ID" --query "NetworkAcls[?IsDefault==false].NetworkAclId" --output text) -split "\s+"
foreach ($nacl_id in $NETWORK_ACL_IDS) {
    aws ec2 delete-network-acl --network-acl-id $nacl_id
}

# Release Elastic IPs
Write-Output "Releasing Elastic IPs..."
$ALLOCATION_IDS = (aws ec2 describe-addresses --query "Addresses[?AssociationId!=null && NetworkInterfaceId!=null && InstanceId!=null && PublicIp!=null].[AllocationId]" --output text) -split "\s+"
foreach ($allocation_id in $ALLOCATION_IDS) {
    aws ec2 release-address --allocation-id $allocation_id
}

# Delete the VPC
Write-Output "Deleting VPC..."
aws ec2 delete-vpc --vpc-id $VPC_ID

Write-Output "VPC and all associated resources have been deleted."