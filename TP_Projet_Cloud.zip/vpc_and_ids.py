import boto3
import time
from botocore.exceptions import ClientError

# AWS credentials and configuration
aws_access_key_id = 'AKIA4KBPYIJT4UJAWRYZ'
aws_secret_access_key = '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'
region_name = 'us-east-1'
key_name = 'vockey'

# Boto3 session and resource
session = boto3.Session(
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
    region_name=region_name
)
ec2 = session.resource('ec2')
client = session.client('ec2')

# Variables to store created resources
created_resources = {
    'vpc': None,
    'subnets': [],
    'igw': None,
    'nat_gw': None,
    'route_tables': [],
    'security_groups': [],
    'instances': [],
    'elastic_ips': [],
    'network_interfaces': [],
    'traffic_mirror_targets': [],
    'traffic_mirror_filters': [],
    'traffic_mirror_sessions': []
}



    # Create VPC

vpc = ec2.create_vpc(CidrBlock='10.0.0.0/16')
vpc.create_tags(Tags=[{"Key": "Name", "Value": "my_vpc"}])
vpc.wait_until_available()
created_resources['vpc'] = vpc
print(f"VPC created: {vpc.id}")

# Create subnets

public_subnet = ec2.create_subnet(CidrBlock='10.0.0.0/20', VpcId=vpc.id, AvailabilityZone='us-east-1a')
private_subnet = ec2.create_subnet(CidrBlock='10.0.16.0/20', VpcId=vpc.id, AvailabilityZone='us-east-1a')
created_resources['subnets'].extend([public_subnet.id, private_subnet.id])
print(f"Public subnet created: {public_subnet.id}")
print(f"Private subnet created: {private_subnet.id}")

# Create an Internet Gateway and attach it to the VPC

igw = ec2.create_internet_gateway()
vpc.attach_internet_gateway(InternetGatewayId=igw.id)
created_resources['igw'] = igw
print(f"Internet Gateway created and attached: {igw.id}")

# Create a NAT Gateway in the public subnet

allocation = client.allocate_address(Domain='vpc')
nat_gw = client.create_nat_gateway(SubnetId=public_subnet.id, AllocationId=allocation['AllocationId'])
nat_gw_id = nat_gw['NatGateway']['NatGatewayId']
created_resources['nat_gw'] = nat_gw_id
created_resources['elastic_ips'].append(allocation['AllocationId'])
print(f"NAT Gateway created: {nat_gw_id}")

# Wait for NAT Gateway to become available

print("Waiting for NAT Gateway to become available...")
while True:
    nat_gw = client.describe_nat_gateways(NatGatewayIds=[nat_gw_id])['NatGateways'][0]
    if nat_gw['State'] == 'available':
        break
    time.sleep(10)
print("NAT Gateway is available")

# Create a route table and a route for the public subnet

public_route_table = vpc.create_route_table()
public_route_table.create_route(
    DestinationCidrBlock='0.0.0.0/0',
    GatewayId=igw.id
)
public_route_table.associate_with_subnet(SubnetId=public_subnet.id)
created_resources['route_tables'].append(public_route_table)
print(f"Public route table created and route added: {public_route_table.id}")

# Create a route table and a route for the private subnet

private_route_table = vpc.create_route_table()
private_route_table.create_route(
    DestinationCidrBlock='0.0.0.0/0',
    NatGatewayId=nat_gw_id
)
private_route_table.associate_with_subnet(SubnetId=private_subnet.id)
created_resources['route_tables'].append(private_route_table)
print(f"Private route table created and route added: {private_route_table.id}")

# Create security groups

web_sg = ec2.create_security_group(GroupName='web_sg', Description='Web security group', VpcId=vpc.id)
db_sg = ec2.create_security_group(GroupName='db_sg', Description='DB security group', VpcId=vpc.id)
snort_sg = ec2.create_security_group(GroupName='snort_sg', Description='snort security group', VpcId=vpc.id)
created_resources['security_groups'].extend([web_sg.id, db_sg.id, snort_sg.id])
print(f"Web security group created: {web_sg.id}")
print(f"DB security group created: {db_sg.id}")
print(f"snort security group created: {snort_sg.id}")

# Authorize ingress rules for web security group

web_sg.authorize_ingress(
    IpPermissions=[
        {
            'IpProtocol': 'tcp',
            'FromPort': 80,
            'ToPort': 80,
            'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
        },
        {
            'IpProtocol': 'tcp',
            'FromPort': 22,
            'ToPort': 22,
            'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
        }
    ]
)
print(f"Ingress rules added to web security group")

# Authorize ingress rules for db security group

db_sg.authorize_ingress(
    IpPermissions=[
        {
            'IpProtocol': 'tcp',
            'FromPort': 3306,
            'ToPort': 3306,
            'IpRanges': [{'CidrIp': '10.0.0.0/16'}]  # Only allow traffic from the VPC
        },
        {
            'IpProtocol': 'tcp',
            'FromPort': 22,
            'ToPort': 22,
            'IpRanges': [{'CidrIp': '10.0.0.0/16'}]
        }
    ]
)
print(f"Ingress rules added to db security group")

# Authorize ingress rules for snort security group

snort_sg.authorize_ingress(
    IpPermissions=[
        {
            'IpProtocol': 'tcp',
            'FromPort': 22,
            'ToPort': 22,
            'IpRanges': [{'CidrIp': '10.0.0.0/16'}]  # Only allow traffic from the VPC
        },
        {
            'IpProtocol': 'udp',
            'FromPort':4789 ,
            'ToPort': 4789,
            'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
        }
    ]
)
print(f"Ingress rules added to snort security group")

# UserData scripts

apache_user_data = '''#!/bin/bash
    wget https://raw.githubusercontent.com/Rikall99/script_auth_website/main/script_apache.sh -O script.sh
    chmod 777 script.sh
    sudo ./script.sh
'''

mariadb_user_data ='''#!/bin/bash
    wget https://raw.githubusercontent.com/Rikall99/script_auth_website/main/script_mariadb.sh -O script.sh
    chmod 777 script.sh
    sudo ./script.sh
'''

snort_user_data = '''#!/bin/bash
    wget https://raw.githubusercontent.com/Rikall99/script_auth_website/main/script_snort.sh -O script.sh
    chmod 777 script.sh
    sudo ./script.sh
'''

# Launch MariaDB instance

mariadb_instance = ec2.create_instances(
    ImageId='ami-04b70fa74e45c3917',  # Replace with your desired AMI ID
    MinCount=1,
    MaxCount=1,
    InstanceType='t3.micro',
    KeyName=key_name,
    NetworkInterfaces=[{
        'SubnetId': private_subnet.id,
        'DeviceIndex': 0,
        'AssociatePublicIpAddress': False,
        'Groups': [db_sg.id],
        'PrivateIpAddress': '10.0.16.45'
    }],
    UserData=mariadb_user_data,
    TagSpecifications=[
        {
            'ResourceType': 'instance',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': 'mariadb'
                },
            ]
        },
    ]
)[0]

mariadb_instance_id = mariadb_instance.id
created_resources['instances'].append(mariadb_instance_id)
print(f"MariaDB instance launched: {mariadb_instance_id}")

# Launch Apache instance

apache_instance = ec2.create_instances(
    ImageId='ami-04b70fa74e45c3917',  # Replace with your desired AMI ID
    MinCount=1,
    MaxCount=1,
    InstanceType='t3.micro',
    KeyName=key_name,
    NetworkInterfaces=[{
        'SubnetId': public_subnet.id,
        'DeviceIndex': 0,
        'AssociatePublicIpAddress': True,
        'Groups': [web_sg.id]
    }],
    UserData=apache_user_data,
    TagSpecifications=[
        {
            'ResourceType': 'instance',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': 'apache'
                },
            ]
        },
    ]
)[0]

apache_instance_id = apache_instance.id
created_resources['instances'].append(apache_instance_id)
print(f"Apache instance launched: {apache_instance_id}")

# Launch snort instance

snort_instance = ec2.create_instances(
    ImageId='ami-04b70fa74e45c3917',  # Replace with your desired AMI ID
    MinCount=1,
    MaxCount=1,
    InstanceType='t3.micro',
    KeyName=key_name,
    NetworkInterfaces=[{
        'SubnetId': private_subnet.id,
        'DeviceIndex': 0,
        'AssociatePublicIpAddress': False,
        'Groups': [snort_sg.id],
        'PrivateIpAddress': '10.0.16.46'
    }],
    UserData=snort_user_data,
    TagSpecifications=[
        {
            'ResourceType': 'instance',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': 'snort'
                },
            ]
        },
    ]
)[0]

snort_instance_id = snort_instance.id
created_resources['instances'].append(snort_instance_id)
print(f"snort instance launched: {snort_instance_id}")

# Wait for instances to be in running state

print("Waiting for instances to be running...")
for instance_id in [apache_instance_id, mariadb_instance_id, snort_instance_id]:
    instance = ec2.Instance(instance_id)
    instance.wait_until_running()
    instance.reload()
print("All instances are running")

# Get public IP of Apache instance and private IPs of MariaDB and snort instances

apache_ip = ec2.Instance(apache_instance_id).public_ip_address
mariadb_ip = ec2.Instance(mariadb_instance_id).private_ip_address
snort_ip = ec2.Instance(snort_instance_id).private_ip_address
print(f"Apache instance public IP: {apache_ip}")
print(f"MariaDB instance private IP: {mariadb_ip}")
print(f"snort instance private IP: {snort_ip}")

# Traffic Mirroring

print("Setting up Traffic Mirroring...")
source_network_interface_id = apache_instance.network_interfaces_attribute[0]['NetworkInterfaceId']
target_network_interface_id = snort_instance.network_interfaces_attribute[0]['NetworkInterfaceId']

print(f"Target network interface ID: {target_network_interface_id}")

traffic_mirror_target = client.create_traffic_mirror_target(
    NetworkInterfaceId=target_network_interface_id,
    Description='Traffic mirror target for Snort'
    )

traffic_mirror_target_id = traffic_mirror_target['TrafficMirrorTarget']['TrafficMirrorTargetId']

print(f"Created new traffic mirror target: {traffic_mirror_target_id}")

traffic_mirror_filter = client.create_traffic_mirror_filter(
    Description='Traffic Mirror Filter All',
    TagSpecifications=[
        {
            'ResourceType': 'traffic-mirror-filter',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': 'TrafficMirrorFilter'
                }
            ]
        }
    ]
)
traffic_mirror_filter_id = traffic_mirror_filter['TrafficMirrorFilter']['TrafficMirrorFilterId']

print(traffic_mirror_filter_id)

client.create_traffic_mirror_filter_rule(
    TrafficMirrorFilterId=traffic_mirror_filter_id,
    TrafficDirection='ingress',
    RuleNumber=100,
    RuleAction='accept',
    DestinationCidrBlock='0.0.0.0/0',
    SourceCidrBlock='0.0.0.0/0',
    Description='Ingress rule'
)

client.create_traffic_mirror_filter_rule(
    TrafficMirrorFilterId=traffic_mirror_filter_id,
    TrafficDirection='egress',
    RuleNumber=100,
    RuleAction='accept',
    DestinationCidrBlock='0.0.0.0/0',
    SourceCidrBlock='0.0.0.0/0',
    Description='egress rule'
)

traffic_mirror_session = client.create_traffic_mirror_session(
    NetworkInterfaceId=source_network_interface_id,
    TrafficMirrorTargetId=traffic_mirror_target_id,
    TrafficMirrorFilterId=traffic_mirror_filter_id,
    SessionNumber=1,
    Description='Traffic Mirror Session Apache to Snort')

print(f"Created new traffic mirror session: {traffic_mirror_session['TrafficMirrorSession']['TrafficMirrorSessionId']}")

#created_resources['traffic_mirror_sessions'].append(traffic_mirror_session['TrafficMirrorSession']['TrafficMirrorSessionId'])

print("Setup complete")

print(vpc.id)